#!/bin/bash
#----------------------------------------------------------------------------------------#
# If you encounter any issues with this script, or have suggestions or feature requests, #
# please open an issue at: https://github.com/Muthukumar-Subramaniam/server-hub/issues   #
#----------------------------------------------------------------------------------------#

source /server-hub/common-utils/color-functions.sh
source /server-hub/qemu-kvm-manage/scripts-to-manage-vms/functions/defaults.sh

# Function to show help
fn_show_help() {
    print_cyan "Usage: qlabvmctl disk-resize [OPTIONS] [hostname]
Options:
  -f, --force          Force power-off without prompt if VM is running
  -d, --disk <disk>    Disk target to resize (e.g., vdb, vdc,vdd, all, default: prompt)
  -g, --gib <size>     Size in GiB to increase (multiple of 5, range: 5-50, default: prompt)
  -h, --help           Show this help message

Arguments:
  hostname             Name of the VM (optional, will prompt if not given)

Examples:
  qlabvmctl disk-resize vm1                      # Interactive mode with prompts
  qlabvmctl disk-resize -f vm1                   # Force power-off if running
  qlabvmctl disk-resize -d vdb -g 5 vm1          # Add 5GiB to vdb with prompts
  qlabvmctl disk-resize -f -d vdc -g 10 vm1      # Fully automated: add 10GiB to vdc
  qlabvmctl disk-resize -f -d vdc,vdd -g 10 vm1  # Fully automated: add 10GiB to vdc and vdd
  qlabvmctl disk-resize -f -d all -g 10 vm1      # Fully automated: add 10GiB to all additional disks

Note: This script only resizes additional disks (vdb, vdc, etc.). 
      Use 'qlabvmctl resize -t disk' for OS disk (vda) resizing.
"
}

# Parse arguments
force_poweroff=false
vm_hostname_arg=""
disk_target_arg=""
gib_arg=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        -h|--help)
            fn_show_help
            exit 0
            ;;
        -f|--force)
            force_poweroff=true
            shift
            ;;
        -d|--disk)
            if [[ -z "$2" || "$2" == -* ]]; then
                print_error "Option -d/--disk requires a value."
                exit 1
            fi
            disk_target_arg="$2"
            shift 2
            ;;
        -g|--gib)
            if [[ -z "$2" || "$2" == -* ]]; then
                print_error "Option -g/--gib requires a value."
                exit 1
            fi
            gib_arg="$2"
            shift 2
            ;;
        -*)
            print_error "Unknown option: $1"
            fn_show_help
            exit 1
            ;;
        *)
            if [[ -n "$vm_hostname_arg" ]]; then
                print_error "Multiple hostnames provided. Only one VM can be processed at a time."
                fn_show_help
                exit 1
            fi
            vm_hostname_arg="$1"
            shift
            ;;
    esac
done

# Use argument or prompt for hostname
source /server-hub/qemu-kvm-manage/scripts-to-manage-vms/functions/input-hostname.sh "$vm_hostname_arg"

# Check if VM exists in 'virsh list --all'
if ! sudo virsh list --all | awk '{print $2}' | grep -Fxq "$qemu_kvm_hostname"; then
    print_error "VM \"$qemu_kvm_hostname\" does not exist."
    exit 1
fi

fn_shutdown_or_poweroff() {
    # If force flag is set, try graceful shutdown first, then force if needed
    if [[ "$force_poweroff" == true ]]; then
        print_task "Shutting down VM (graceful then force if needed)..."
        source /server-hub/qemu-kvm-manage/scripts-to-manage-vms/functions/shutdown-vm.sh
        SHUTDOWN_VM_CONTEXT="Attempting graceful shutdown" SHUTDOWN_VM_STRICT=false shutdown_vm "$qemu_kvm_hostname" &>/dev/null
        
        # Wait for VM to shut down with timeout
        TIMEOUT=30
        ELAPSED=0
        while sudo virsh list | awk '{print $2}' | grep -Fxq "$qemu_kvm_hostname"; do
            if (( ELAPSED >= TIMEOUT )); then
                source /server-hub/qemu-kvm-manage/scripts-to-manage-vms/functions/poweroff-vm.sh
                if ! POWEROFF_VM_CONTEXT="Forcing power off after timeout" POWEROFF_VM_STRICT=true poweroff_vm "$qemu_kvm_hostname" &>/dev/null; then
                    print_task_fail
                    exit 1
                fi
                break
            fi
            sleep 2
            ((ELAPSED+=2))
        done
        
        if ! sudo virsh list | awk '{print $2}' | grep -Fxq "$qemu_kvm_hostname"; then
            print_task_done
        fi
        return 0
    fi
    
    print_warning "VM \"$qemu_kvm_hostname\" is still running!"
    print_notify "Select an option to proceed:
	1) Try Graceful Shutdown
	2) Force Power Off
	q) Quit"

    read -rp "Enter your choice: " selected_choice

    case "$selected_choice" in
        1)
            print_info "Initiating graceful shutdown..."
            source /server-hub/qemu-kvm-manage/scripts-to-manage-vms/functions/shutdown-vm.sh
            if ! SHUTDOWN_VM_CONTEXT="Initiating graceful shutdown" shutdown_vm "$qemu_kvm_hostname"; then
                exit 1
            fi
            
            # Wait for VM to shut down with timeout
            print_info "Waiting for VM \"${qemu_kvm_hostname}\" to shut down (timeout: 60s)..."
            TIMEOUT=60
            ELAPSED=0
            while sudo virsh list | awk '{print $2}' | grep -Fxq "$qemu_kvm_hostname"; do
                if (( ELAPSED >= TIMEOUT )); then
                    print_warning "VM did not shut down within ${TIMEOUT}s."
                    print_info "You may want to force power off instead."
                    exit 1
                fi
                sleep 2
                ((ELAPSED+=2))
            done
            print_success "VM has been shut down successfully. Proceeding further."
            ;;
        2)
            print_info "Forcing power off..."
            source /server-hub/qemu-kvm-manage/scripts-to-manage-vms/functions/poweroff-vm.sh
            if ! POWEROFF_VM_CONTEXT="Forcing power off" POWEROFF_VM_STRICT=true poweroff_vm "$qemu_kvm_hostname"; then
                exit 1
            fi
            ;;
        q)
            print_info "Quitting without any action."
            exit 0
            ;;
        *)
            print_error "Invalid option!"
            exit 1
            ;;
    esac
}

VM_DIR="/kvm-hub/vms/${qemu_kvm_hostname}"

# Verify VM directory exists
if [[ ! -d "$VM_DIR" ]]; then
    print_error "VM directory does not exist: $VM_DIR"
    exit 1
fi

# Get list of additional disks (excluding vda/OS disk)
declare -a ADDITIONAL_DISKS
declare -A DISK_PATHS
declare -A SEEN_DISKS
for disk_file in "$VM_DIR"/*.qcow2; do
    [[ -e "$disk_file" ]] || continue
    BASENAME=$(basename "$disk_file")
    # Skip OS disk (vda)
    if [[ "$BASENAME" == "${qemu_kvm_hostname}.qcow2" || "$BASENAME" == "${qemu_kvm_hostname}_vda.qcow2" ]]; then
        continue
    fi
    # Extract disk target (e.g., vdb, vdc)
    if [[ "$BASENAME" =~ ${qemu_kvm_hostname}_(vd[b-z])\.qcow2 ]]; then
        DISK_TARGET="${BASH_REMATCH[1]}"
        # Only add if not already seen (avoid duplicates)
        if [[ -z "${SEEN_DISKS[$DISK_TARGET]}" ]]; then
            ADDITIONAL_DISKS+=("$DISK_TARGET")
            DISK_PATHS["$DISK_TARGET"]="$disk_file"
            SEEN_DISKS["$DISK_TARGET"]=1
        fi
    fi
done

# Check if there are any additional disks
if (( ${#ADDITIONAL_DISKS[@]} == 0 )); then
    print_error "No additional disks found for VM \"$qemu_kvm_hostname\"."
    print_info "This script only resizes additional disks (vdb, vdc, etc.)."
    print_info "Use 'qlabvmctl resize -t disk' to resize the OS disk."
    exit 1
fi

# Track if we're in interactive mode
INTERACTIVE_MODE=false
if [[ -z "$disk_target_arg" ]]; then
    INTERACTIVE_MODE=true
fi

# Track resized disks for interactive multi-resize
declare -a RESIZED_DISKS
declare -A DISK_NEW_SIZES

# Main resize loop (for interactive mode with multiple disks)
while true; do
    # Validate disk target argument if provided
    if [[ -n "$disk_target_arg" ]]; then
        # Normalize to lowercase
        disk_target_arg=$(echo "$disk_target_arg" | tr '[:upper:]' '[:lower:]')
        
        # Check if user wants to resize all disks
        if [[ "$disk_target_arg" == "all" ]]; then
            RESIZE_ALL=true
        elif [[ "$disk_target_arg" == *,* ]]; then
            # Comma-separated list of disks
            RESIZE_ALL=false
            RESIZE_MULTIPLE=true
            IFS=',' read -ra SELECTED_DISKS_ARRAY <<< "$disk_target_arg"
            
            # Validate each disk in the list
            for disk in "${SELECTED_DISKS_ARRAY[@]}"; do
                disk=$(echo "$disk" | xargs)  # Trim whitespace
                FOUND=false
                for available_disk in "${ADDITIONAL_DISKS[@]}"; do
                    if [[ "$disk" == "$available_disk" ]]; then
                        FOUND=true
                        break
                    fi
                done
                
                if [[ "$FOUND" == false ]]; then
                    print_error "Disk \"$disk\" not found or is not an additional disk."
                    print_info "Available additional disks: ${ADDITIONAL_DISKS[*]}"
                    exit 1
                fi
            done
        else
            # Single disk
            FOUND=false
            for disk in "${ADDITIONAL_DISKS[@]}"; do
                if [[ "$disk" == "$disk_target_arg" ]]; then
                    FOUND=true
                    break
                fi
            done
            
            if [[ "$FOUND" == false ]]; then
                print_error "Disk \"$disk_target_arg\" not found or is not an additional disk."
                print_info "Available additional disks: ${ADDITIONAL_DISKS[*]}"
                exit 1
            fi
            
            SELECTED_DISK="$disk_target_arg"
            RESIZE_ALL=false
            RESIZE_MULTIPLE=false
        fi
    else
        # Prompt for disk selection
        # Filter out already resized disks
        declare -a AVAILABLE_DISKS
        for disk in "${ADDITIONAL_DISKS[@]}"; do
            ALREADY_RESIZED=false
            for resized in "${RESIZED_DISKS[@]}"; do
                if [[ "$disk" == "$resized" ]]; then
                    ALREADY_RESIZED=true
                    break
                fi
            done
            if [[ "$ALREADY_RESIZED" == false ]]; then
                AVAILABLE_DISKS+=("$disk")
            fi
        done
        
        # Check if any disks left to resize
        if (( ${#AVAILABLE_DISKS[@]} == 0 )); then
            print_info "All additional disks have been resized."
            break
        fi
        
        print_info "Available additional disks for VM \"$qemu_kvm_hostname\":"
        for i in "${!AVAILABLE_DISKS[@]}"; do
            disk="${AVAILABLE_DISKS[$i]}"
            echo "  $((i+1))) $disk"
        done
        
        # Only show "all" option if more than one disk available and this is first iteration
        if (( ${#AVAILABLE_DISKS[@]} > 1 && ${#RESIZED_DISKS[@]} == 0 )); then
            echo "  a) All additional disks"
        fi
        
        while true; do
            if (( ${#AVAILABLE_DISKS[@]} > 1 && ${#RESIZED_DISKS[@]} == 0 )); then
                read -rp "Select disk to resize (1-${#AVAILABLE_DISKS[@]}, a): " disk_choice
            else
                read -rp "Select disk to resize (1-${#AVAILABLE_DISKS[@]}): " disk_choice
            fi
            
            if [[ "$disk_choice" == "a" || "$disk_choice" == "A" ]] && (( ${#AVAILABLE_DISKS[@]} > 1 && ${#RESIZED_DISKS[@]} == 0 )); then
                RESIZE_ALL=true
                print_info "Selected: All additional disks"
                break
            elif [[ "$disk_choice" =~ ^[0-9]+$ ]] && (( disk_choice >= 1 && disk_choice <= ${#AVAILABLE_DISKS[@]} )); then
                SELECTED_DISK="${AVAILABLE_DISKS[$((disk_choice-1))]}"
                print_info "Selected disk: $SELECTED_DISK"
                RESIZE_ALL=false
                break
            else
                if (( ${#AVAILABLE_DISKS[@]} > 1 && ${#RESIZED_DISKS[@]} == 0 )); then
                    print_error "Invalid selection! Enter a number between 1 and ${#AVAILABLE_DISKS[@]}, or 'a' for all."
                else
                    print_error "Invalid selection! Enter a number between 1 and ${#AVAILABLE_DISKS[@]}."
                fi
            fi
        done
    fi

    # Shutdown VM if running (only once, before first resize operation)
    if [[ "${VM_SHUTDOWN_DONE:-false}" == false ]]; then
        if ! sudo virsh list | awk '{print $2}' | grep -Fxq "$qemu_kvm_hostname"; then
            print_info "VM \"$qemu_kvm_hostname\" is not running. Proceeding further."
        else
            fn_shutdown_or_poweroff
        fi
        VM_SHUTDOWN_DONE=true
    fi

    # Validate gib argument if provided (only first iteration in interactive mode)
    if [[ -n "$gib_arg" ]] || [[ "$INTERACTIVE_MODE" == false ]]; then
        if [[ -n "$gib_arg" ]]; then
            if ! [[ "$gib_arg" =~ ^[0-9]+$ ]]; then
                print_error "Invalid disk increase size: $gib_arg. Must be numeric."
                exit 1
            fi
            if (( gib_arg % 5 != 0 )); then
                print_error "Disk increase size must be a multiple of 5 GiB."
                exit 1
            fi
            if (( gib_arg < 5 || gib_arg > 50 )); then
                print_error "Disk increase size must be between 5 and 50 GiB."
                exit 1
            fi
            grow_size_gib="$gib_arg"
            print_info "Using increase size: ${grow_size_gib} GiB"
        fi
    else
        # Prompt for disk increase size - show current sizes now that VM is stopped
        if [[ "$RESIZE_ALL" == true ]]; then
            print_info "Resizing all additional disks:"
            for disk in "${AVAILABLE_DISKS[@]}"; do
                disk_path="${DISK_PATHS[$disk]}"
                disk_size=$(sudo qemu-img info "$disk_path" | grep "virtual size" | grep -o '[0-9]\+ GiB' | cut -d' ' -f1)
                echo "  - $disk: ${disk_size} GiB"
            done
        else
            # Show current size for single disk
            SELECTED_DISK_PATH="${DISK_PATHS[$SELECTED_DISK]}"
            current_disk_gib=$(sudo qemu-img info "$SELECTED_DISK_PATH" | grep "virtual size" | grep -o '[0-9]\+ GiB' | cut -d' ' -f1)
            print_info "Current size of $SELECTED_DISK: ${current_disk_gib} GiB"
        fi
        print_info "Allowed sizes for increase: Steps of 5 GiB — e.g., 5, 10, 15... up to 50 GiB"

        while true; do
            read -rp "Enter increase size (GiB): " grow_size_gib

            if ! [[ "$grow_size_gib" =~ ^[0-9]+$ ]]; then
                print_error "Invalid input for increase size of disk. Must be numeric."
                continue
            fi

            if (( grow_size_gib % 5 != 0 )); then
                print_error "Increase in disk size must be a multiple of 5 GiB."
                continue
            fi

            if (( grow_size_gib < 5 || grow_size_gib > 50 )); then
                print_error "Increase in disk size must be between 5 and 50 GiB."
                continue
            fi
            break
        done
    fi

    # Perform the disk resize
    if [[ "$RESIZE_ALL" == true ]]; then
        # Resize all additional disks
        for disk in "${AVAILABLE_DISKS[@]}"; do
            disk_path="${DISK_PATHS[$disk]}"
            current_disk_gib=$(sudo qemu-img info "$disk_path" | grep "virtual size" | grep -o '[0-9]\+ GiB' | cut -d' ' -f1)
            
            print_task "Growing $disk by ${grow_size_gib} GiB..." nskip
            if error_msg=$(sudo qemu-img resize "$disk_path" +${grow_size_gib}G 2>&1); then
                print_task_done
                new_disk_size=$(( current_disk_gib + grow_size_gib ))
                print_info "Disk $disk resized from ${current_disk_gib} GiB to ${new_disk_size} GiB."
                RESIZED_DISKS+=("$disk")
                DISK_NEW_SIZES["$disk"]="$new_disk_size"
            else
                print_task_fail
                print_error "$error_msg"
                exit 1
            fi
        done
        # After resizing all, we're done
        break
    elif [[ "${RESIZE_MULTIPLE:-false}" == true ]]; then
        # Resize multiple specific disks (comma-separated)
        for disk in "${SELECTED_DISKS_ARRAY[@]}"; do
            disk=$(echo "$disk" | xargs)  # Trim whitespace
            disk_path="${DISK_PATHS[$disk]}"
            current_disk_gib=$(sudo qemu-img info "$disk_path" | grep "virtual size" | grep -o '[0-9]\+ GiB' | cut -d' ' -f1)
            
            print_task "Growing $disk by ${grow_size_gib} GiB..." nskip
            if error_msg=$(sudo qemu-img resize "$disk_path" +${grow_size_gib}G 2>&1); then
                print_task_done
                new_disk_size=$(( current_disk_gib + grow_size_gib ))
                print_info "Disk $disk resized from ${current_disk_gib} GiB to ${new_disk_size} GiB."
                RESIZED_DISKS+=("$disk")
                DISK_NEW_SIZES["$disk"]="$new_disk_size"
            else
                print_task_fail
                print_error "$error_msg"
                exit 1
            fi
        done
        # After resizing multiple, we're done
        break
    else
        # Resize single disk
        SELECTED_DISK_PATH="${DISK_PATHS[$SELECTED_DISK]}"
        current_disk_gib=$(sudo qemu-img info "$SELECTED_DISK_PATH" | grep "virtual size" | grep -o '[0-9]\+ GiB' | cut -d' ' -f1)
        
        print_task "Growing $SELECTED_DISK by ${grow_size_gib} GiB..." nskip
        if error_msg=$(sudo qemu-img resize "$SELECTED_DISK_PATH" +${grow_size_gib}G 2>&1); then
            print_task_done
            new_disk_size=$(( current_disk_gib + grow_size_gib ))
            print_info "Disk $SELECTED_DISK resized from ${current_disk_gib} GiB to ${new_disk_size} GiB."
            RESIZED_DISKS+=("$SELECTED_DISK")
            DISK_NEW_SIZES["$SELECTED_DISK"]="$new_disk_size"
        else
            print_task_fail
            print_error "$error_msg"
            exit 1
        fi
    fi
    
    # In automated mode or after resizing all, exit loop
    if [[ "$INTERACTIVE_MODE" == false ]] || [[ "$RESIZE_ALL" == true ]]; then
        break
    fi
    
    # In interactive mode, check if there are more disks available and ask if user wants to resize another
    declare -a REMAINING_DISKS
    for disk in "${ADDITIONAL_DISKS[@]}"; do
        ALREADY_RESIZED=false
        for resized in "${RESIZED_DISKS[@]}"; do
            if [[ "$disk" == "$resized" ]]; then
                ALREADY_RESIZED=true
                break
            fi
        done
        if [[ "$ALREADY_RESIZED" == false ]]; then
            REMAINING_DISKS+=("$disk")
        fi
    done
    
    # If no more disks to resize, exit
    if (( ${#REMAINING_DISKS[@]} == 0 )); then
        break
    fi
    
    # Ask if user wants to resize another disk
    echo
    while true; do
        read -rp "Do you want to resize another disk? (y/n): " resize_another
        case "$resize_another" in
            y|Y|yes|Yes|YES)
                # Continue loop
                break
                ;;
            n|N|no|No|NO)
                # Exit loop
                break 2
                ;;
            *)
                print_error "Invalid input! Enter 'y' for yes or 'n' for no."
                ;;
        esac
    done
done

# Start the VM
print_task "Starting VM \"$qemu_kvm_hostname\"..." nskip
if error_msg=$(sudo virsh start "$qemu_kvm_hostname" 2>&1); then
    print_task_done
    if (( ${#RESIZED_DISKS[@]} > 1 )); then
        print_success "[VM: $qemu_kvm_hostname] Successfully resized ${#RESIZED_DISKS[@]} disk(s) and started."
        for disk in "${RESIZED_DISKS[@]}"; do
            print_info "  - $disk: Final size ${DISK_NEW_SIZES[$disk]} GiB"
        done
    elif (( ${#RESIZED_DISKS[@]} == 1 )); then
        disk="${RESIZED_DISKS[0]}"
        print_success "[VM: $qemu_kvm_hostname] Disk $disk successfully resized to ${DISK_NEW_SIZES[$disk]} GiB and VM started."
    else
        print_warning "[VM: $qemu_kvm_hostname] No disks were resized, but VM started successfully."
    fi
    print_info "You may need to resize the partitions and filesystems at the operating system level."
else
    print_task_fail
    print_error "Could not start VM \"$qemu_kvm_hostname\"."
    print_error "$error_msg"
    exit 1
fi
